#!/bin/bash
# Simple APK build script
echo "Starting APK build..."

# Install dependencies
pip install -r requirements.txt

# Initialize buildozer if needed
if [ ! -f "buildozer.spec" ]; then
    buildozer init
fi

# Build APK
buildozer android debug

# Check for APK
find . -name "*.apk" -type f -exec ls -la {} \;

echo "Build completed!"
